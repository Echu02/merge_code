=============================
-
Merge labels script
-
=============================

What the code does?

This code is done to merge 2 folders of different class labels. For example, I want to merge the labels of class 'person' and class 'gun', execute this script and you will have an output file with both labels in one.

Scripted by: Lyron and Ezequiel

