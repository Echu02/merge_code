from distutils.dir_util import copy_tree
import os

path1 = "./labels1"
path2 = "./labels2"
save_path = "./output"

dir1 = os.listdir( path1 + "/labels")
dir2 = os.listdir( path2 + "/labels")

copy_tree(path2, save_path)


for file in dir1:
    f, e = os.path.splitext(file)
    print(f)
    labels1 = open(path1+"/labels/"+f+".txt", 'r')
    output = open(save_path+"/labels/"+f+".txt", 'a')
    lines1 = labels1.readlines()
    lines3 = output.writelines(lines1)